![](Table.jpg)

Watch this video to understand the code and how this works

https://www.youtube.com/watch?v=JxugkDrs6Tg
